﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Ionic.Zip;
using NTP.Prices.Forexite;

namespace ForexDomainObject
{
    /// <summary>
    /// extension methods
    /// </summary>
    public static class ForexDomainObjectExtensions
    {
    }
}
